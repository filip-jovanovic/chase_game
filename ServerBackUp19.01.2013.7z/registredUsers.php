<html>
<body>

<?php

$mysql_host = "mysql5.000webhost.com";
$mysql_database = "a2067837_android";
$mysql_user = "a2067837_filip";
$mysql_password = "123123abc";


$con = mysql_connect($mysql_host,$mysql_user,$mysql_password);
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db($mysql_database, $con);

$result = mysql_query("SELECT * FROM  `player` LIMIT 0 , 100");

mysql_close($con);

while($row = mysql_fetch_array($result))
  {
  echo " Username : ";
  echo $row['username'];
  echo " password : ";
  echo $row['password'];
  echo " registration_id : ";
  echo $row['registration_id'];
  echo "<br />";
  
  }
?>
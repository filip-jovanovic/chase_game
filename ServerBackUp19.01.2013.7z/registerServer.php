<?php
include 'postRequest.php';

$c2dm_url = "https://www.google.com/accounts/ClientLogin";
$post_data = "Email=c2dm.04062012@gmail.com&Passwd=123123abc&accountType=GOOGLE&source=edutest&service=ac2dm";
$res = do_post_request($c2dm_url,$post_data);

$auth = explode('Auth=',$res);

$mysql_host = "mysql5.000webhost.com";
$mysql_database = "a2067837_android";
$mysql_user = "a2067837_filip";
$mysql_password = "123123abc";

$con = mysql_connect($mysql_host,$mysql_user,$mysql_password);
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db($mysql_database, $con);

$result = mysql_query("INSERT INTO authorisation_keys ( auth_key ) VALUES ('$auth[1]')");

?>

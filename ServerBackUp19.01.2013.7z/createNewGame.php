<?php
	include "database_helper.php";
	$sql = createNewGame($_POST["name"], $_POST["mapId"],$_POST["thief"]);
	$id = mysql_fetch_row($sql);
	echo $id[0];
?>
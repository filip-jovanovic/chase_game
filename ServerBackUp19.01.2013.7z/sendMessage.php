<?php
include 'postRequest.php';
function sendGCMMessage($data_to_be_sent, $registrationIds){
	$data_string = '{ "data": '. stripslashes($data_to_be_sent) .
		', "registration_ids": '. stripslashes($registrationIds) .' }';
		
	$ch = curl_init('https://android.googleapis.com/gcm/send');                                                                      
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);                                                                  
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
		'Content-Type: application/json',                                                                                
		'Authorization: key=AIzaSyDGuC1_kqe-bGT1_-SnHEaJbjMCvBeb0fc')                                                                       
	);                                                                                                                   
	 
	$result = curl_exec($ch);

	echo "<br> Message info: " . $result;
	echo "<br> <br> JSON: ".$data_string;
}
?>
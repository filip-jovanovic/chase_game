<?php
	include "database_helper.php";
	$sql = getBuildingList($_GET["mapId"]);
	$postojiTakav = mysql_num_rows($sql);
	if($postojiTakav!=0){
		$data_string = '{ "buildings": [';
		while($row = mysql_fetch_row($sql)) {
			$id = $row[0];
			$name = $row[1];
			$lat = $row[2];
			$lon = $row[3];
			$data_string .= '{ "id": "'.$id.'", "lat": "'.$lat.'","lon": "'.$lon.'","name": "'.$name.'" },';
		}
		$data_string = rtrim($data_string, ",").'], "items": [';
	}
	else 
		$data_string = "Error";
		
	$sql = getItemList($_GET["mapId"]);
	$postojiTakav = mysql_num_rows($sql);
	if($data_string!='Error')
	{
		if($postojiTakav!=0){
			$data_string2 = '';
			while($row = mysql_fetch_row($sql)) {
					$id = $row[0];
					$name = $row[1];
					$lat = $row[2];
					$lon = $row[3];
					$data_string2 .= '{ "id": "'.$id.'", "lat": "'.$lat.'","lon": "'.$lon.'","name": "'.$name.'" },';
			}
		$data_string =$data_string. rtrim($data_string2, ",").']}';
		}
	}
	else 
		$data_string = "Error";

	echo $data_string;
?>
<?php
	include "database_helper.php";
	$sql = exitGame($_POST["game_id"],$_POST["player_id"],$_POST["place"]);
	/*$exists = mysql_num_rows($sql);
	if($exists!=0){
		$data_string = '';
		$row = mysql_fetch_row($sql);
		$game_name = $row[0];
		$map_id = $row[1];
		$thief = $row[2];
		$map_lat = $row[6];
		$map_lon = $row[7];
		if(($row[3]!=null)&&($row[4]!=null)&&($row[5]!=null))		
			$data_string = 'Igra je zauzeta!';
		else
		{
			if($row[3]==null)
			{
				$update_res = putPoliceman($game_id, $player_id, "cop_1");
				$cop_1 =  $player_id;
				$cop_2 = 'empty';
				$cop_3 = 'empty';
			}
			if(($row[4]==null)&&($cop_2!='empty'))
			{
				$cop_1 = $row[3];
				$update_res = putPoliceman($game_id, $player_id, "cop_2");
				$cop_2 =  $player_id;
				$cop_3 = 'empty';
			}
			if(($row[5]==null)&&($cop_3!='empty'))
			{
				$cop_1 = $row[3];
				$cop_2 = $row[4];
				$update_res = putPoliceman($game_id, $player_id, "cop_3");
				$cop_3 =  $player_id;
			}
				
			$data_string = '{ "game_name": "'.$game_name.'", "map_id": "'.$map_id.'","map_latitude": "'.$map_lat.'","map_longitude": "'.$map_lon.'",
			"thief": "'.$thief.'", "cop_1": "'.$cop_1.'", "cop_2": "'.$cop_2.'", "cop_3": "'.$cop_3.'" }';
		}
	}
*/
	echo $data_string;
?>
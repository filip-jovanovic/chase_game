<?php
	include "database_helper.php";
	$sql = updatePlayerLocations($_POST["player_id"], $_POST["longitude"], $_POST["latitude"]);
	
	$sql = getPlayerLocations($_POST["game_id"]);
	$postojiTakav = mysql_num_rows($sql);
	if($postojiTakav!=0){
		$data_string = '{ "player_locations": [';
		$count = 0;
		$reg_ids="[";
		while($row = mysql_fetch_row($sql)) {
			$id = $row[0];
			$longitude = $row[1];
			$latitude = $row[2];
			$checked = $row[3];
			$reg_ids .="\"".$id."\",";
			if($checked=="true")
				$count++;
			$data_string .= '{ "player_id": "'.$id.'", "longitude": "'.$longitude.'", "latitude": "'.$latitude.'" },';
		}
		$data_string = rtrim($data_string, ",").']}';
		$reg_ids = rtrim($reg_ids, ",").']';
		include "sendMessage.php";
		sendGCMMessage($data_string, $reg_ids);
	}
	else 
		$data_string = "Trenutno nema postojecih igara.";
	echo $data_string;
?>
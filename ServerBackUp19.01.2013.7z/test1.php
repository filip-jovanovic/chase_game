<?php
$received = $_POST["data_string"];
echo 'POST var is:'. $received;

?>
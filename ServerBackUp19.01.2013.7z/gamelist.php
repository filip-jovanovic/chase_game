<?php
	include "database_helper.php";
	$sql = getGameList();
	$postojiTakav = mysql_num_rows($sql);
	if($postojiTakav!=0){
		$data_string = '{ "games": [';
		while($row = mysql_fetch_row($sql)) {
			$id = $row[0];
			$name = $row[1];
			$count = 1;
			if($row[3]!=null)
				$count++;
			if($row[4]!=null)
				$count++;
			if($row[5]!=null)
				$count++;
			$data_string .= '{ "id": "'.$id.'", "name": "'.$name.'", "count": "'.$count.'" },';
		}
		$data_string = rtrim($data_string, ",").']}';
	}
	else 
		$data_string = "Trenutno nema postojecih igara.";

	echo $data_string;
?>
<?php
	//funkcija connect vraca pokazivac na konekciju koji se kasnije koristi da bi se zatvorila ta konekcija
	function connect(){
		/*  
		1: "die()" ce izaci iz skripte i pokazati gresku ako se desi nesto lose sa "connect" ili "select" funkcijama.
		2: "mysql_connect()" greska znaci da su username/password pogreseni.
		3: "mysql_select_db()" greska obicno znaci da baza ne postoji.
		*/ 
		$mysql_host = "mysql5.000webhost.com";
		$mysql_database = "a2067837_android";
		$mysql_user = "a2067837_filip";
		$mysql_password = "123123abc";

		//konkcija na bazu
		$con = mysql_connect($mysql_host,$mysql_user,$mysql_password) or die ("Ne moze se konektovati na mysql bazu");
		mysql_select_db($mysql_database, $con) or die ("Baza ne postoji"); 
		return $con;
	}

	//funkcija vraca ID korisnika koji se ulogovao ili 0 ako taj korisnik ne postoji u bazi podataka
	function login($username, $password, $regId){
		$con = connect();
		$sql = mysql_query("SELECT * FROM player WHERE username='$username' AND password='$password' LIMIT 1" );
		$postojiTakav = mysql_num_rows($sql);
		if($postojiTakav==1){
			$row=mysql_fetch_array($sql);
			$idKorisnika=$row[0];
			mysql_query("UPDATE player SET registration_id='$regId'  WHERE username='$username'");
		}
		else {
			$sql = mysql_query("SELECT * FROM player WHERE username='$username' LIMIT 1" );
			$postojiTakav = mysql_num_rows($sql);
			if ($postojiTakav==1)
				$idKorisnika = "Error: Pogresili ste sifru, pokusajte ponovo.";
			else
				$idKorisnika = "Error: Korisnik sa tim imenom ne postoji";
		}
		mysql_close($con);
		return $idKorisnika;
	}

	//funkcija vraca ID korisnika koji se prijavio ili 0 ako taj korisnik vec postoji u bazi
	function signUp($username, $password, $regId){
		$con = connect();
		$sql1 = mysql_query("SELECT * FROM player WHERE username='$username' AND password='$password' LIMIT 1" );
		$postojiTakav = mysql_num_rows($sql1);
		if($postojiTakav==0){
			//ako ne postoji korisnik sa tim imenom
			$sql2 = mysql_query("INSERT INTO player (username, password, registration_id ) VALUES ('$username','$password','$regId')");
			if($sql2){
				$sql3 = mysql_query("SELECT * FROM player WHERE username='$username' AND password='$password' LIMIT 1" );
				$postojiTakav = mysql_num_rows($sql3);
				if($postojiTakav==1){
					$row=mysql_fetch_array($sql3);
					$idKorisnika=$row[0];
					mysql_query("UPDATE player SET registration_id='$regId'  WHERE username='$username'");
				}
				else 
					$idKorisnika = "Error: db_error1";
			}				
			else 
				$idKorisnika = "Error: db_error2";
		}
		else 
			$idKorisnika = "Error: vec_postoji";
		mysql_close($con);
		return $idKorisnika;
	}
	
	//funkcija vraca JSON koji sadrzi listu svih igara (game)
	function getGameList1 (){
		$con = connect();
		$sql = mysql_query("SELECT * FROM game " );
		$postojiTakav = mysql_num_rows($sql);
		$rows = array();
		if($postojiTakav!=0){
			while($row = mysql_fetch_row($sql)) 
				$rows[] = $row;
			$rezultat = json_encode($rows);
		}
		else 
			$rezultat = "Trenutno nema kreiranih igara.";
		mysql_close($con);
		return $rezultat;
	}
	
	function getGameList (){
		$con = connect();
		$sql = mysql_query("SELECT game_id,game_name,thief,cop_1,cop_2,cop_3 FROM game " );
		mysql_close($con);
		return $sql;	
	}
	
	function getGame ($game_id){
		$con = connect();
		$sql = mysql_query("SELECT game_name,map_id,thief,cop_1,cop_2,cop_3, latitude, longitude from (
							SELECT game_name,map_id,thief,cop_1,cop_2,cop_3 FROM game WHERE game_id='$game_id') g, map 
							WHERE g.map_id = map.id" );
		mysql_close($con);
		return $sql;	
	}
	
	function putPoliceman($game_id, $id, $position){
		$con = connect();
		$sql = mysql_query("UPDATE game SET $position ='$id' WHERE game_id='$game_id'");
		mysql_close($con);
		return $sql;	
	}
	
	//funkcija vraca JSON koji sadrzi listu svih mapa
	function getMapList (){
		$con = connect();
		$sql = mysql_query("SELECT id,name,latitude,longitude FROM map " );
		mysql_close($con);
		return $sql;
	}
	
	//funkcija vraca JSON koji sadrzi listu svih zgrada odredjene mape
	function getBuildingList ($game){
		$con = connect();
		$sql = mysql_query("SELECT * FROM building WHERE map_id='$game'" );
		mysql_close($con);
		return $sql;
	}
	
	//funkcija vraca JSON koji sadrzi listu svih predmeta odredjene mape
	function getItemList ($game){
		$con = connect();
		$sql = mysql_query("SELECT * FROM item WHERE map_id='$game'" );
		mysql_close($con);
		return $sql;
	}
	
	//funkcija vraca JSON koji sadrzi listu lokacija svih igraca odredjene igre
	function getPlayerLocations($game){
		$con = connect();
		$sql = mysql_query("SELECT player_id,longitude,latitude,checked 
					FROM player_location 
					WHERE game_id='$game'" );
		mysql_close($con);
		return $sql;
	}
	
	//funkcija dodaje novu lokaciju igraca
	function newPlayerLocation($game_id, $player_id, $longitude, $latitude){
		$con = connect();
		$sql = mysql_query("DELETE FROM player_location
				WHERE player_id='$player_id'");

		$sql = mysql_query("INSERT INTO `player_location` 
			(`game_id`, `player_id`, `longitude`, `latitude`, `checked`) 
			VALUES ('$game_id','$player_id', '$longitude', '$latitude', 'true');");
		mysql_close($con);
		return $sql;
	}
	
	//funkcija updatuje lokaciju igraca
	function updatePlayerLocations($player_id, $longitude, $latitude){
		$con = connect();
		$sql = mysql_query("UPDATE player_location 
				SET longitude='$longitude', latitude='$latitude', checked='true'
				WHERE player_id='$player_id'");
		mysql_close($con);
		return $sql;
	}
	
	//funkcija updatuje lokaciju igraca
	function createNewGame($name, $mapId, $thief){
		$con = connect();
		$sql = mysql_query("INSERT INTO `game` 
			(`game_name`, `map_id`, `thief`) 
			VALUES ('$name','$mapId', '$thief');");
		$sql = mysql_query("SELECT game_id
					FROM game 
					WHERE game_name ='$name'" );
		mysql_close($con);
		return $sql;
	}
	
	//funkcija koja brise igraca iz tabele game ili brise igru ako si lopov
	function exitGame($game_id,$player_id,$place){
		if($place==0){
			$con = connect();
			$sql = mysql_query("DELETE FROM game
				WHERE thief='$player_id'");
		}
		else{
			$con = connect();
			$cop = "cop_".$place;
			$sql = mysql_query("UPDATE game 
				SET $cop=NULL
				WHERE $cop='$player_id'");
		}
	}
?>
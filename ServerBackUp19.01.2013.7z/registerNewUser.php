<html>
<body>

<?php

$mysql_host = "mysql5.000webhost.com";
$mysql_database = "a2067837_android";
$mysql_user = "a2067837_filip";
$mysql_password = "123123abc";

$devid = $_POST[deviceid];
$regid = $_POST[registrationid];

$con = mysql_connect($mysql_host,$mysql_user,$mysql_password);
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db($mysql_database, $con);

mysql_query("INSERT INTO registred_devices (
Registration_id ,
Android_id ) VALUES 
('$regid','$devid')");

mysql_close($con);

?>
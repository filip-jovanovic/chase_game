<?php
	include "database_helper.php";
	$sql = newPlayerLocation($_POST["game_id"], $_POST["player_id"], 123456, 123456);
?>
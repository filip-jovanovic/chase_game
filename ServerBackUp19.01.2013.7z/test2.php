<?php
include 'postRequest.php';


$mysql_host = "mysql5.000webhost.com";
$mysql_database = "a2067837_android";
$mysql_user = "a2067837_filip";
$mysql_password = "123123abc";

$con = mysql_connect($mysql_host,$mysql_user,$mysql_password);
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db($mysql_database, $con);

$result = mysql_result(mysql_query("SELECT auth_key from authorisation_keys order by auth_key desc limit 1 "),0,0); 

echo $result;
?>

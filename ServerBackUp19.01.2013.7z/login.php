<?php
	include "database_helper.php";
	if($_POST['method'] == "login"){
		$idkorisnika = login($_POST['username'], $_POST['password'], $_POST['regId']);
		echo $idkorisnika;
	} else if($_POST['method'] == "signup"){
		$idkorisnika = signUp($_POST['username'], $_POST['password'],$_POST['regId']);
		echo $idkorisnika;
	} else 
		echo "Error: Post metoda nije definisana";
?>
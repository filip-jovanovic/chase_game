<?php
	include "database_helper.php";
	$sql = getMapList();
	$postojiTakav = mysql_num_rows($sql);
	if($postojiTakav!=0){
		$data_string = '{ "maps": [';
		while($row = mysql_fetch_row($sql)) {
			$id = $row[0];
			$name = $row[1];
			$lat = $row[2];
			$lon = $row[3];
			$data_string .= '{ "id": "'.$id.'", "name": "'.$name.'", "latitude": "'.$lat.'", "longitude": "'.$lon.'" },';
		}
		$data_string = rtrim($data_string, ",").']}';
	}
	else 
		$data_string = "Trenutno nema predefinisanih mapa.";

	echo $data_string;
?>